# Getting Started with Learn English App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

### I have used Bootstrap with React to make this Web Aplication.

### Also I have used React Router in this application.

### There is Five directory 
 * Home
 * AboutUS
 * Gallery
 * Courses
 * ContactUS

## Also There is a Header section and Footer secton.

### I enjoy very much by building this Web App.

 

### Deployment 

This section has moved here: [https://review-website-syedhasibrahman.netlify.app/](https://review-website-syedhasibrahman.netlify.app/)
 